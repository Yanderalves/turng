from State import State
class Machine: 
    def __init__(self, q: State, w: str, max_steps: int):
        self.q = q          
        self.w = w            
        self.max_steps = max_steps
        self.fita = []        
        
        
        self.set_fita_space(len(w) + 20) 
        self.init_fita(w)
        print(f"Palavra de entrada: '{w}'")
        self.print_tape()

    def run(self):
        if self.q is None or self.w is None:
            return False
            
        steps = 0
        while steps < self.max_steps:
            # Para se não houver mais transições (estado de parada)
            if not self.q.transitions:
                break
                
            # Lê o símbolo atual da fita
            read_symbol = self.fita[self.current]
            
            # Procura por uma transição válida a partir do estado atual e símbolo lido
            transition = self.q.transition(read_symbol)
            
            if transition is None:
                # Se não houver transição, a máquina para.
                print(f"Nenhuma transição encontrada para o estado {self.q.getName()} com o símbolo '{read_symbol}'")
                break

            # Executa a transição
            edge = transition.getEdge()
            
            # 1. Escreve o novo símbolo na fita
            self.fita[self.current] = edge.getWrite()
            
            # 2. Move a cabeça da fita
            if edge.getDirection() == 'D':
                self.current += 1
            elif edge.getDirection() == 'E':
                self.current -= 1

            # 3. Muda para o próximo estado
            self.q = transition.getState()
            
            steps += 1
            print(f"Passo {steps}: -> {self.q.getName()}", end=" | ")
            self.print_tape()

        if steps >= self.max_steps:
            print("Limite máximo de passos atingido!")

        return self.print_result()

    def print_tape(self):
        """ Imprime o conteúdo da fita e a posição da cabeça. """
        tape_str = "".join([c if c is not None else ' ' for c in self.fita])
        head_str = " " * self.current + "^"
        print(f"Fita: {tape_str}")
        print(f"      {head_str}")

    def print_result(self):
        """ Imprime o resultado final e retorna True (aceito) ou False (rejeitado). """
        if self.q.isFinal:
            print(f"\nReconheceu: '{self.w}'")
            return True
        else:
            print(f"\nNão reconheceu: '{self.w}'")
            return False

    def init_fita(self, w):
        # Escreve a palavra de entrada 'w' na fita a partir da posição inicial
        for char in list(w):
            self.fita[self.current] = char
            self.current += 1
        
        # Reposiciona a cabeça no início da palavra
        self.current = self.start_pos

    def set_fita_space(self, _range):
        """ Prepara a fita com espaços em branco (None). """
        self.range = _range
        self.max = self.range * 2
        
        self.fita = [None] * (self.max + 2)
        
        self.start_pos = self.range + 1
        self.current = self.start_pos
        self.max = self.max + 1