from Tests_Possiveis import teste_anbn, teste_multiplo_3

def main():
    """
    Executa os testes da Máquina de Turing.
    """
    print("=========================================")
    print("    INICIANDO SIMULADOR DE MÁQUINA DE TURING    ")
    print("=========================================\n")
    
    teste_anbn()
    
    # teste_multiplo_3()
    
    print("\n=========================================")
    print("      EXECUÇÃO FINALIZADA      ")
    print("=========================================")

if __name__ == "__main__":
    main()