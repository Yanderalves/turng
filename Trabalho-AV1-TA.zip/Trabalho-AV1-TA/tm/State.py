from Edge import Edge
from Transition import Transition

class State:
    def __init__(self, name: str):
        self.name = name
        self.isFinal = False
        self.transitions = []

    def getName(self): return self.name
	
    def setFinal(self): self.isFinal = True

    def addTransition(self, state, read: str, write: str, direction: str):
        edge = Edge.instance(read, write, direction)
        return self.addTransitions(state, edge)

    def addTransitions(self, state, *edges):
        for edge in edges:
            transition = Transition(state, edge)
            if transition in self.transitions:
                continue
            self.transitions.append(transition)
        return self

    def transition(self, read_symbol: str):
        for t in self.transitions:
            e = t.getEdge()
            # Trata o None (branco) como um símbolo válido para transição
            if e.getRead() == read_symbol:
                return t
        return None
    
    def equals(self, s):
        if isinstance(s, State):
            return s.getName() == self.getName()
        return False
    
    def hashCode(self):
        return hash(self.getName())