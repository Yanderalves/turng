class Edge:
    def __init__(self, read: str, write: str, direction: str):
        self.read = read
        self.write = write
        self.direction = direction

    def getRead(self): return self.read
    def getWrite(self): return self.write
    def getDirection(self): return self.direction

    @staticmethod
    def instance(read: str, write: str, direction: str):
        return Edge(read, write, direction)

    def equals(self, o):
        if isinstance(o, Edge):
            return self.read == o.getRead() and \
                   self.write == o.getWrite() and \
                   self.direction == o.getDirection()
        return False

    def __repr__(self):
        return f'[{self.read if self.read is not None else " "}, {self.write if self.write is not None else " "}, {self.direction}]'

    @staticmethod
    def testAB(a: str, b: str):
        return a == b