from State import State
from Machine import Machine

def teste_anbn(): # Livre de contexto: { a^n b^n | n >= 0 }
    print("Testando: { a^n b^n | n >= 0 }")
    q0 = State('q0')
    q1 = State('q1')
    q2 = State('q2')
    q3 = State('q3')
    q4 = State('q4')
    qf = State('qf')
    qf.setFinal()

    # q0: Início. Procura por 'a'. Se encontrar, troca por 'A' e vai para q1.
    # Se encontrar 'B' (marcador de 'b' já visitado), pula para a direita (q4).
    # Se encontrar um espaço em branco (None), vai para a verificação final (q3).
    q0.addTransition(q1, 'a', 'A', 'D')
    q0.addTransition(q3, None, None, 'E')
    q0.addTransition(q4, 'B', 'B', 'D')

    # q1: Move para a direita sobre 'a's e 'B's procurando por um 'b'.
    # Ao encontrar 'b', troca por 'B' e começa a voltar para a esquerda (q2).
    q1.addTransition(q1, 'a', 'a', 'D')
    q1.addTransition(q1, 'B', 'B', 'D')
    q1.addTransition(q2, 'b', 'B', 'E')

    # q2: Move para a esquerda sobre 'a's e 'B's procurando pelo marcador 'A'.
    # Ao encontrar 'A', move um passo para a direita e volta para q0 para o próximo ciclo.
    q2.addTransition(q2, 'a', 'a', 'E')
    q2.addTransition(q2, 'B', 'B', 'E')
    q2.addTransition(q0, 'A', 'A', 'D')
    
    # q4: Pula todos os 'B's para a direita.
    # Se encontrar um espaço em branco, vai para a verificação final (q3).
    q4.addTransition(q4, 'B', 'B', 'D')
    q4.addTransition(q3, None, None, 'E')

    # q3: Estado de verificação. Move para a esquerda sobre 'A's e 'B's.
    # Se encontrar um espaço em branco à esquerda da palavra, vai para o estado final (qf).
    q3.addTransition(q3, 'A', 'A', 'E')
    q3.addTransition(q3, 'B', 'B', 'E')
    q3.addTransition(qf, None, None, 'D')

    # Palavra a ser testada. "aabb" deve ser aceita.
    w = 'aabb' 
    # Para testar uma rejeição, você pode usar 'aaabbb' (errado) ou 'aaabbbb'
    # w = 'aaabbbb'

    mt = Machine(q0, w, 50) # Aumentado o limite de passos
    mt.run()
    print("-" * 40)

def teste_multiplo_3(): # Regular: { w in Σ^* | w é um número binário múltiplo de 3}
    print("Testando: { w in Σ^* | w é um número binário múltiplo de 3 }")
    # Os estados representam o resto da divisão por 3. q0 (resto 0), q1 (resto 1), q2 (resto 2)
    q0 = State('q0_rem0') # Resto 0
    q1 = State('q1_rem1') # Resto 1
    q2 = State('q2_rem2') # Resto 2
    q0.setFinal()

    # Transições para '0' (equivale a multiplicar por 2)
    # rem(n*2, 3)
    q0.addTransition(q0, '0', '0', 'D') # 0*2 = 0 -> rem 0
    q1.addTransition(q2, '0', '0', 'D') # 1*2 = 2 -> rem 2
    q2.addTransition(q1, '0', '0', 'D') # 2*2 = 4 -> rem 1

    # Transições para '1' (equivale a multiplicar por 2 e somar 1)
    # rem(n*2+1, 3)
    q0.addTransition(q1, '1', '1', 'D') # 0*2+1=1 -> rem 1
    q1.addTransition(q0, '1', '1', 'D') # 1*2+1=3 -> rem 0
    q2.addTransition(q2, '1', '1', 'D') # 2*2+1=5 -> rem 2
    
    # Adicionando transições para o fim da palavra (espaço em branco)
    # Se a máquina para em um estado final, a palavra é aceita.
    q0.addTransition(q0, None, None, 'N') # Fim, permanece no estado final
    q1.addTransition(q1, None, None, 'N') # Fim
    q2.addTransition(q2, None, None, 'N') # Fim

    # 110 (binário) = 6 (decimal), que é múltiplo de 3. Deve ser aceito.
    w = '110'
    mt = Machine(q0, w, 20)
    mt.run()
    print("-" * 40)

